import './global.css'
import './app1.js'
import './app2.js'
import './app3.js'
import './app4.js'
import './reset.css'
document.querySelector('img').remove()
