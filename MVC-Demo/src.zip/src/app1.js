import './app1.css'
import $ from 'jquery'

// put all the data relevant actions to "Model"
const m = {
    // initialize data
    data: {
        n: localStorage.getItem('n')
    }
}

// put all the v relevant actions to "View"
const v = {
    // initialize html
    html: `<section id="app1">
        <div class="output">
            <span id="number">{{n}}</span>
        </div>
        <div class="actions">
            <button id="add1">+1</button>
            <button id="minus1">-1</button>
            <button id="mul2">*2</button>
            <button id="divide2">÷2</button>
        </div>
    </section>`,
    update() {
        // render data to page
        c.ui.number.text(m.data.n || 100)
    },
    render() {
       const $element = $(v.html).appendTo($('body > .page'))
    }
}

// the remaining actions to "Controller"
const c = {
    //这个初始化方法为了避免，element的id在 v.render() 方法之前执行，这样
    init() {
        c.ui = {
            // the important elements
            btn1: $('#add1'),
            btn2: $('#minus1'),
            btn3: $('#mul2'),
            btn4: $('#divide2'),
            number: $('#number')
        }
        c.bindEvents()
        console.log('c.ui.btn1');
        console.log(typeof m.data.n);
    },
    bindEvents() {
        // bind the event to certain action
        c.ui.btn1.on('click', () => {
            let n = parseInt(c.ui.number.text())
            n += 1
            localStorage.setItem('n', n)
            c.ui.number.text(n)
        })

        c.ui.btn2.on('click', () => {
            let n = parseInt(c.ui.number.text())
            n -= 1
            localStorage.setItem('n', n)
            c.ui.number.text(n)
        })

        c.ui.btn3.on('click', () => {
            let n = parseInt(c.ui.number.text())
            n *= 2
            localStorage.setItem('n', n)
            c.ui.number.text(n)
        })

        c.ui.btn4.on('click', () => {
            let n = parseInt(c.ui.number.text())
            n /= 2
            localStorage.setItem('n', n)
            c.ui.number.text(n)
        })
    }
}

//the first time render html
v.render()
c.init()

